-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2020 at 04:57 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pi`
--

-- --------------------------------------------------------

--
-- Table structure for table `cliente`
--

CREATE TABLE `cliente` (
  `idCliente` int(11) NOT NULL,
  `nomeCliente` varchar(60) DEFAULT NULL,
  `cpfCliente` varchar(11) DEFAULT NULL,
  `sexo` varchar(10) DEFAULT NULL,
  `telefone` varchar(11) NOT NULL,
  `estado` varchar(2) NOT NULL,
  `cep` int(8) NOT NULL,
  `bairro` varchar(60) NOT NULL,
  `logradouro` varchar(60) NOT NULL,
  `complemento` varchar(60) NOT NULL,
  `rua` varchar(60) NOT NULL,
  `numero` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cliente`
--

INSERT INTO `cliente` (`idCliente`, `nomeCliente`, `cpfCliente`, `sexo`, `telefone`, `estado`, `cep`, `bairro`, `logradouro`, `complemento`, `rua`, `numero`) VALUES
(2, 'GABRIEL MARIANO OLIMPIO DE SIQUEIRA', '2147483647', 'M', '83426314', 'DF', 71660220, 'Lago Sul', 'Shis Qi28', 'Casa', '18', 10),
(3, 'GABRIEL MARIANO OLIMPIO DE SIQUEIRA', '05857742188', 'M', '83426314', 'DF', 71660220, 'Lago Sul', 'Shis Qi28', 'Casa', '18', 10),
(4, 'Rosenete', '05214520322', 'F', '2147483647', 'DF', 71660, 'Lago Sul', 'Shis Qi28', 'Casa', '18', 10),
(8, 'GABRIEL MARIANO OLIMPIO DE SIQUEIRA', '05857742188', 'M', '83426314', 'DF', 71660220, 'Lago Sul', 'Shis Qi28', 'Casa', '18', 10),
(10, 'Teste alteracao', '27920812804', 'M', '61991960169', 'AC', 71660220, 'Lago Sul', 'Shis Qi28', 'Casa', '18', 10);

-- --------------------------------------------------------

--
-- Table structure for table `funcionario`
--

CREATE TABLE `funcionario` (
  `idFuncionario` int(11) NOT NULL,
  `nome` varchar(60) NOT NULL,
  `cpf` varchar(11) NOT NULL,
  `telefone` varchar(11) NOT NULL,
  `email` varchar(60) NOT NULL,
  `sexo` varchar(9) NOT NULL,
  `estadoCivil` varchar(30) NOT NULL,
  `cargo` varchar(60) NOT NULL,
  `dataNascimento` date NOT NULL,
  `dataRegistro` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `funcionario`
--

INSERT INTO `funcionario` (`idFuncionario`, `nome`, `cpf`, `telefone`, `email`, `sexo`, `estadoCivil`, `cargo`, `dataNascimento`, `dataRegistro`) VALUES
(2, 'Teste', '000122555', '12121522', 'teste@gmail..com', 'Solte', '', '0000-00-00', '2000-02-02', '2019-11-11');

-- --------------------------------------------------------

--
-- Table structure for table `os`
--

CREATE TABLE `os` (
  `idOs` int(11) NOT NULL,
  `valoOrcamento` decimal(10,2) NOT NULL,
  `dataInicio` date NOT NULL,
  `dataFim` date NOT NULL,
  `modeloProduto` varchar(90) NOT NULL,
  `marcaProduto` varchar(60) NOT NULL,
  `observacaoProduto` varchar(90) NOT NULL,
  `valorPago` decimal(10,2) NOT NULL,
  `dataPagamento` date NOT NULL,
  `statusOs` varchar(60) NOT NULL,
  `FK_Funcionario` int(11) NOT NULL,
  `FK_Cliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `os`
--

INSERT INTO `os` (`idOs`, `valoOrcamento`, `dataInicio`, `dataFim`, `modeloProduto`, `marcaProduto`, `observacaoProduto`, `valorPago`, `dataPagamento`, `statusOs`, `FK_Funcionario`, `FK_Cliente`) VALUES
(4, '1200.00', '2020-02-02', '2020-03-02', 'Xp', 'Sam', '', '1200.00', '2020-03-02', 'Pronto', 122555, 2147483647);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`idCliente`);

--
-- Indexes for table `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`idFuncionario`);

--
-- Indexes for table `os`
--
ALTER TABLE `os`
  ADD PRIMARY KEY (`idOs`),
  ADD KEY `FK_Funcionario` (`FK_Funcionario`),
  ADD KEY `FK_Cliente` (`FK_Cliente`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cliente`
--
ALTER TABLE `cliente`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `funcionario`
--
ALTER TABLE `funcionario`
  MODIFY `idFuncionario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `os`
--
ALTER TABLE `os`
  MODIFY `idOs` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
