<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Cadastro de O.S.</title>

    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">O.S. control</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.html">In&iacute;cio</a></li>
                    <li>
                        <div class="dropdown">
                            <button class="dropbtn">Cadastrar</button>
                            <div class="dropdown-content">
                                <a href="cadastraCliente.php">Cadastra Cliente</a>
                                <a href="cadastraFuncionario.php">Cadastra Funcionário</a>
                               
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="dropdown">
                            <button class="dropbtn">Gerenciar</button>
                            <div class="dropdown-content">
                                <a href="gerenciaClientes.php">Gerenciar Clientes</a>
                                 <a href="gerenciaFuncionario.php">Gerenciar Funcionarios</a>
                                 <a href="gerenciaOs.php">Gerenciar Os</a>
                            </div>
                        </div>
                    </li>
                    <li><a href="#">Ajuda</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!--espaço de uma coluna pra outra-->
    <div id="main" class="container-fluid">
        <h3 class="page-header">Ordem de serviço </h3>
        <form action="../Controler/insereOs.php">
            <div class="row">
                <div class="form-group col-md-4">
                    <label class="lblCodCliente" for="exampleInputEmail1">Valor Do Orçamento:</label>
                    <input type="text" class="form-control" id="lblOrcamento" name="lblOrcamento" placeholder="Digite o Valor Do Orçamento">
                </div>
                <div class="form-group col-md-4">
                    <label for="exampleInputEmail1">Data do Inicio:</label>
                    <input type="date" class="form-control" id="lblDataInicio" name="lblDataInicio" placeholder="Digite a Data do Inicio">
                </div>
                <div class="form-group col-md-4">
                    <label for="exampleInputEmail1">Data do Fim:</label>
                    <input type="date" class="form-control" id="lblDataFim" name="lblDataFim" placeholder="Digite a Data do Fim">
                </div>
                <div class="form-group col-md-4">
                    <label for="exampleInputEmail1">Modelo do Produto:</label>
                    <input type="text" class="form-control" id="lblModelo" name="lblModelo" placeholder="Digite o Modelo do Produto">
                </div>
				<div class="form-group col-md-4">
                    <label for="exampleInputEmail1">Marca:</label>
                    <input type="text" class="form-control" id="lblMarca" name="lblMarca" placeholder="Digite a marca do Produto">
                </div>
                <div class="form-group col-md-4">
                    <label for="exampleInputEmail1">Valor Pago:</label>
                    <input type="text" class="form-control" id="lblValorPago" name="lblValorPago" placeholder="Digite o Valor Pago">
                </div>
                <div class="form-group col-md-4">
                    <label for="exampleInputEmail1">Data do Pagamento:</label>
                    <input type="date" class="form-control" id="lblDataPagamento" name="lblDataPagamento" placeholder="Digite a Data do Pagamento">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-3">
                    <label for="exampleInputEmail1">Status da O.S</label>
                    <input type="text" class="form-control" id="lblStatus" name="lblStatus" placeholder="Digite o status da O.S">
                </div>
                <div class="form-group col-md-3">
                    <label for="exampleInputEmail1">CPF Funcionario</label>
                    <input type="text" class="form-control" id="lblCpfFunc" name="lblCpfFunc" placeholder="Digite o CPF do Funcionario">
                </div>
				<div class="form-group col-md-3">
                    <label for="exampleInputEmail1">CPF Cliente</label>
                    <input type="text" class="form-control" id="lblCpfCliente" name="lblCpfCliente" placeholder="Digite o CPF do Cliente">
                </div>
            </div>
            <div class="row" id="botoes">
                <div class="col-md-12">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    <a href="template.html" class="btn btn-default">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>

</html>
