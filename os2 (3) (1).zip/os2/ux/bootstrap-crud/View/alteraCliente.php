<!DOCTYPE html>
<?php
  include_once "../Controler/conectabd.inc.php";
  include "../Controler/funcoes.php";
  $id = $_GET["id"];
  $linha = le_consulta($link, $id);
?>
<html lang="pt-br">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Altera Cliente</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
   
	
</head>

		<?php 
        include_once "../Controler/conectabd.inc.php";
        ?>

<body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">O.S. control</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.html">In&iacute;cio</a></li>
                    <li>
                        <div class="dropdown">
                            <button class="dropbtn">Cadastrar</button>
                            <div class="dropdown-content">
                                <a href="cadastraFuncionario.php">Cadastrar Funcionário</a>
                                <a href="cadastraOs.php">Cadastrar O.S.</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="dropdown">
                            <button class="dropbtn">Gerenciar</button>
                            <div class="dropdown-content">
                                <a href="gerenciaClientes.php">Gerenciar Clientes</a>
                                <a href="gerenciaFuncionario.php">Gerenciar Funcionários</a>
                                <a href="gerenciaOs.php">Gerenciar Os</a>
								
                            </div>
                        </div>
                    </li>
                    <li><a href="#">Ajuda</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div id="main" class="container-fluid">
        <h3 class="page-header">Alterar Cliente</h3>
        <form action="../Controler/alteraCliente.php" method="GET">
            <div class="row">
			
                <div class="form-group col-md-4">
                    <label class="lblCodCliente" for="nome">Nome:</label>
                    <input type="text" class="form-control" id="lblNome" name="lblNome" placeholder="Digite o nome" value="<?php echo $linha["nomeCliente"];?>"> 
                </div>
                <div class="form-group col-md-4">
                    <label for="lblCpf">CPF:</label>
                    <input type="text" class="form-control" id="lblCpf" name="lblCpf" placeholder="***.***.***-**" value="<?php echo $linha["cpfCliente"];?>">
                </div>
                <div class="form-group col-md-4" id="divSexo">
                    <label for="exampleInputEmail1">Sexo:</label>
                    <input type="text" class="form-control" id="lblSexo" name="lblSexo" placeholder="Digite o sexo" value="<?php echo $linha["sexo"];?>">
                </div>
				 <div class="form-group col-md-3" id="divTelefone">
                        <label for="exampleInputEmail1">Telefone:</label>
                        <input type="phone" class="form-control" id="lblTelefone" name="lblTelefone" placeholder="(**)*****-****" value="<?php echo $linha["telefone"];?>">
                    </div>
            </div>
            <div class="container" id="contEnd">
                <h5>Endereço</h5>
                <div class="panel panel-default">
                    <div class="panel-body">
						<div class="form-group" id="ddEstado">
							<label for="exampleFormControlSelect1" >Estado</label>
							<select class="form-control" id="slcEstado" name="slcEstado" value="<?php echo $linha["estado"];?>">
							<option>AC</option>
							<option>AL</option>
							<option>AP</option>
							<option>AM</option>
							<option>BA</option>
							<option>CE</option>
							<option>DF</option>
							<option>ES</option>
							<option>GO</option>
							<option>MA</option>
							<option>MT</option>
							<option>MS</option>
							<option>MG</option>
							<option>PA</option>
							<option>PB</option>
							<option>PE</option>
							<option>PI</option>
							<option>RJ</option>
							<option>RN</option>
							<option>RS</option>
							<option>RO</option>
							<option>RR</option>
							<option>SC</option>
							<option>SP</option>
							<option>SE</option>
							<option>TO</option>
							</select>
						</div>
                        <div class="row">
                            <div class="form-group col-md-3" id="divCidade">
                                <label for="exampleInputEmail1">Cidade:</label>
                                <input type="text" class="form-control" id="lblCidade" name="lblCidade" placeholder="Digite a Cidade" >
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-3" id="divBairro">
                                <label for="exampleInputEmail1">Bairro:</label>
                                <input type="text" class="form-control" id="lblBairro" name="lblBairro" placeholder="Digite o Bairro" value="<?php echo $linha["bairro"];?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-3" id="divLogradouro">
                                <label for="exampleInputEmail1">Logradouro:</label>
                                <input type="text" class="form-control" id="lblLougradouro" name="lblLougradouro" placeholder="Digite o Logradouro" value="<?php echo $linha["logradouro"];?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-3" id="divComplemento">
                                <label for="exampleInputEmail1">Complemento:</label>
                                <input type="text" class="form-control" id="lblComplemento" name="lblComplemento" placeholder="Digite o Complemento" value="<?php echo $linha["complemento"];?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-3" id="divCep">
                                <label for="exampleInputEmail1">Cep:</label>
                                <input type="text" class="form-control" id="lblCep" name="lblCep" placeholder="******-***" value="<?php echo $linha["cep"];?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-3" id="divRua">
                                <label for="exampleInputEmail1">Rua:</label>
                                <input type="text" class="form-control" id="lblRua" name="lblRua" placeholder="Digite o Rua" value="<?php echo $linha["rua"];?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-3" id="divNumero">
                                <label for="exampleInputEmail1">Número:</label>
                                <input type="text" class="form-control" id="lblNumero" name="lblNumero" placeholder="Digite o Número" value="<?php echo $linha["numero"];?>">
                            </div>
                        </div>
						
                    </div>
					<input type="hidden" id="lblId" name="lblId" value="<?php echo $linha["idCliente"];?>">
                </div>
                <div class="row">
                   
                </div>
                <div class="row" id="botoes">
                    <div class="col-md-12">
                        <button type="submit" value="Ok" class="btn btn-primary">Salvar</button>
                        <a href="template.html" class="btn btn-default">Cancelar</a>
                    </div>
                </div>
            </div>
        </form>
        <script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
</body>

</html>
