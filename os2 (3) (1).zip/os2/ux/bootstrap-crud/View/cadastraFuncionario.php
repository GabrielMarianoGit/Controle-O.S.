<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cadastro de Funcionário</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">O.S. control</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.html">In&iacute;cio</a></li>
                    <li>
                        <div class="dropdown">
                           <button class="dropbtn">Cadastrar</button>
                            <div class="dropdown-content">
                                <a href="cadastraCliente.php">Cadastrar Cliente</a>
                                <a href="cadastraOs.php">Cadastrar O.S.</a>
                                
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="dropdown">
                            <button class="dropbtn">Gerenciar</button>
                            <div class="dropdown-content">
                                 <a href="gerenciaClientes.php">Gerenciar Clientes</a>
                                 <a href="gerenciaFuncionario.php">Gerenciar Funcionarios</a>
                                 <a href="gerenciaOs.php">Gerenciar Os</a>
                            </div>
                        </div>
                    </li>
                    <li><a href="#">Ajuda</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div id="main" class="container-fluid">
        <h3 class="page-header">Registro de Funcionarios</h3>
        <form action="../Controler/insereFuncionario.php">
            <div class="row">
                <div class="form-group col-md-3">
                    <label for="exampleInputEmail1">Nome </label>
                    <input type="text" class="form-control" id="lblNomeF" name="lblNomeF" placeholder="Digite o Nome">
                </div>
                <div class="form-group col-md-3">
                    <label for="exampleInputEmail1">CPF</label>
                    <input type="text" class="form-control" id="lblCpfF" name="lblCpfF" placeholder="Digite o CPF">
                </div>
                <div class="form-group col-md-4" id="divTelefoneF">
                    <label for="exampleInputEmail1">Telefone </label>
                    <input type="text" class="form-control" id="lblTelefoneF" name="lblTelefoneF" placeholder="Digite o Telefone">
                </div>
                <div class="form-group col-md-3" id="divEmailF">
                    <label for="exampleInputEmail1">E-mail</label>
                    <input type="text" class="form-control" id="lblEmailF" name="lblEmailF" placeholder="Digite o E-mail">
                </div>
                <div class="form-group col-md-4">
                    <label for="exampleInputEmail1">Codigo do Funcionario </label>
                    <input type="text" class="form-control" id="lblCodigoF" name="lblCodigoF" placeholder="Digite o Codigo do Funcionario">
                </div>
                <div class="form-group col-md-4" id="divSexoF">
                    <label for="exampleInputEmail1">Sexo</label>
                    <input type="text" class="form-control" id="lblSexoF" name="lblSexoF" placeholder="Digite o Sexo">
                </div>
            </div>
            <div class="row">
                <div class="form-group col-md-3">
                    <label for="exampleInputEmail1">Estado Civil</label>
                    <input type="text" class="form-control" id="lblEstadoCivilF" name="lblEstadoCivilF" placeholder="Digite o Estado Civil">
                </div>
                <div class="form-group col-md-3">
                    <label for="exampleInputEmail1">Cargo</label>
                    <input type="text" class="form-control" id="lblCargoF" name="lblCargoF" placeholder="Digite o Cargo">
                </div>
				</br>
				</br>
				</br>
                <div class="form-group col-md-3" id="divDtNascF">
                    <label for="exampleInputEmail1">Data de Nascimento</label>
                    <input type="date" class="form-control" id="lblDataNascF" name="lblDataNascF" placeholder="Digite a Data de Nascimento">
                </div>
                <div class="form-group col-md-3" id="divDtRgtrF"> 
                    <label for="exampleInputEmail1">Data de Registro</label>
                    <input type="date" class="form-control" id="lblDataRgstF" name="lblDataRgstF" placeholder="Digite a Data de Registro">
                </div>
            </div>
			</br>
            <div class="row">
                <div class="col-md-12">
                    <button type="submit" value="OK" class="btn btn-primary">Registrar Funcionario</button>
                    <a href="template.html" class="btn btn-default">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
