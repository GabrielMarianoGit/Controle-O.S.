<!DOCTYPE html>
<!-- cadastro.php 
     lista os cursos cadastrados -->
<html>
	<head>
		<title>O.S. control</title>
		<meta charset="utf-8">
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>O.S. control</title>
		<link href="../css/bootstrap.min.css" rel="stylesheet">
		<link href="../css/style.css" rel="stylesheet">
	</head>
	<body>

	<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">O.S. control</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.html">In&iacute;cio</a></li>
                    <li>
                        <div class="dropdown">
                            <button class="dropbtn">Cadastrar</button>
                            <div class="dropdown-content">
                                <a href="cadastraFuncionario.php">Cadastrar Funcionário</a>
                                <a href="cadastraOs.php">Cadastrar O.S.</a>
                                <a href="cadastraCliente.php">Cadastrar Cliente</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="dropdown">
                            <button class="dropbtn">Gerenciar</button>
                            <div class="dropdown-content">
                                <a href="gerenciaCliente.php">Gerenciar Cliente</a>
                                <a href="gerenciaOs.php">Gerenciar Os</a>
                            </div>
                        </div>
                    </li>
                    <li><a href="#">Ajuda</a></li>
                </ul>
            </div>
        </div>
    </nav>
	</br>
	</br>
	<h1>Funcionários Cadastrados</h1>
	<div id="tabelaCliente">
	<?php //cadastro.php
// lista clientes cadastrados  

  include_once "../Controler/conectabd.inc.php";

  
  
  // lista clientes já cadastrados
  $query = "SELECT idFuncionario, nome, cpf, telefone, email, sexo, estadoCivil, cargo, dataNascimento, dataRegistro FROM funcionario;";
  if ($result = mysqli_query($link, $query)) {
	  echo "<table border='1'>";
	  echo "<tr>
	          <th>ID</th>
			  <th>Nome</th>
			  <th>CPF</th>
			  <th>Telefone</th>
			  <th>Email</th>
			  <th>Sexo</th>
			  <th>Estado Civil</th>
			  <th>Cargo</th>
			  <th>Data Nascimento</th>
			  <th>Data Resgitro</th>
			  <th colspan=\"2\">Ações</th>
			</tr>";
	  // busca os dados lidos do banco de dados
	  while ($row = mysqli_fetch_assoc($result)) {
		  $idFuncionario = $row["idFuncionario"];
		  $nome = $row["nome"];
		  $cpf= $row["cpf"];
		  $telefone = $row["telefone"];
		  $email = $row["email"];
		  $sexo = $row["sexo"];
		  $estadoCivil = $row["estadoCivil"];
		  $cargo = $row["cargo"];
		  $dataNascimento = $row["dataNascimento"];
		  $dataRegistro = $row["dataRegistro"];
		  echo "<tr>";
		  echo "<td> $idFuncionario </td>";
		  echo "<td> $nome </td>";
		  echo "<td> $cpf </td>";
		  echo "<td> $telefone </td>";
		  echo "<td> $email </td>";
		  echo "<td> $sexo </td>";
		  echo "<td> $estadoCivil </td>";
		  echo "<td> $cargo </td>";
		  echo "<td> $dataNascimento </td>";
		  echo "<td> $dataRegistro </td>";
		    
		  // cria link para EXCLUSAO do respectivo id_curso
		  echo '<td><a href="excluiFuncionario.php?id='. $row["idFuncionario"] . '">Excluir</a></td>';
		  // cria link para ALTERACAO do respectivo id_curso
		  echo '<td><a href="alteraFuncionario.php?id='. $row["idFuncionario"] . '"  >Alterar</a></td>';
		  
		  echo "</tr>";
	  }
	  echo "</table>";
	  // libera a área de memória onde está o resultado
	  mysqli_free_result($result);
  }
  // fecha a conexão
  mysqli_close($link);
?>  
</div>
	
	
	
	<script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
	</body>
</html>
