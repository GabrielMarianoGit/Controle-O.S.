<!DOCTYPE html>
<html>
	<head>
	  <title>-Exclusão-</title>
	  <meta charset="utf-8">
	</head>
	<body>
	<?php
	
  $id = $_GET["id"];
  
  include_once "../Controler/conectabd.inc.php";

  $query = "delete from cliente where idCliente=$id;";
  if ($result = mysqli_query($link, $query)) {
	  echo "<h1>Exclusão efetuada com sucesso</h1>";
  }
  
  // fecha a conexão
  mysqli_close($link);
  
 ?>  
 
 <meta http-equiv="refresh" content="2; URL='gerenciaClientes.php'"/>
 
</body>
</html>
