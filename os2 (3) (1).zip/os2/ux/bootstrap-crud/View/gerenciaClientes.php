<!DOCTYPE html>
<!-- cadastro.php 
     lista os cursos cadastrados -->
<html>
	<head>
		<title>O.S. control</title>
		<meta charset="utf-8">
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Cadastro de Cliente</title>
		<link href="../css/bootstrap.min.css" rel="stylesheet">
		<link href="../css/style.css" rel="stylesheet">
	</head>
	<body>

	<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">O.S. control</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.html">In&iacute;cio</a></li>
                    <li>
                        <div class="dropdown">
                            <button class="dropbtn">Cadastrar</button>
                            <div class="dropdown-content">
                                <a href="cadastraFuncionario.php">Cadastrar Funcionário</a>
                                <a href="cadastraOs.php">Cadastrar O.S.</a>
                                <a href="cadastraCliente.php">Cadastrar Clinte</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="dropdown">
                            <button class="dropbtn">Gerenciar</button>
                            <div class="dropdown-content">
                                <a href="gerenciaFuncionario.php">Gerenciar Funcionários</a>
                                <a href="gerenciaOs.php">Gerenciar Os</a>
                            </div>
                        </div>
                    </li>
                    <li><a href="#">Ajuda</a></li>
                </ul>
            </div>
        </div>
    </nav>
	</br>
	</br>
	<h1>Clientes Cadastrados</h1>
	<div id="tabelaCliente">
	<?php //cadastro.php
// lista clientes cadastrados  

  include_once "../Controler/conectabd.inc.php";

  
  
  // lista clientes já cadastrados
  $query = "SELECT idCliente, nomeCliente, cpfCliente, sexo, telefone, estado, cep, bairro, logradouro, complemento, rua, numero FROM cliente;";
  if ($result = mysqli_query($link, $query)) {
	  echo "<table border='1'>";
	  echo "<tr>
	          <th>ID</th>
			  <th>Nome</th>
			  <th>CPF</th>
			  <th>Sexo</th>
			  <th>Telefone</th>
			  <th>Estado</th>
			  <th>Cep</th>
			  <th>Bairro</th>
			  <th>Lougradouro</th>
			  <th>Complemento</th>
			  <th>Rua</th>
			  <th>Numero</th>
			  <th colspan=\"2\">Ações</th>
			</tr>";
	  // busca os dados lidos do banco de dados
	  while ($row = mysqli_fetch_assoc($result)) {
		  $idCliente = $row["idCliente"];
		  $nomeCliente = $row["nomeCliente"];
		  $cpfCliente= $row["cpfCliente"];
		  $sexo = $row["sexo"];
		  $telefone = $row["telefone"];
		  $estado = $row["estado"];
		  $cep = $row["cep"];
		  $bairro = $row["bairro"];
		  $logradouro = $row["logradouro"];
		  $complemento = $row["complemento"];
		  $rua = $row["rua"];
		  $numero = $row["numero"];
		  echo "<tr>";
		  echo "<td> $idCliente </td>";
		  echo "<td> $nomeCliente </td>";
		  echo "<td> $cpfCliente </td>";
		  echo "<td> $sexo </td>";
		  echo "<td> $telefone </td>";
		  echo "<td> $estado </td>";
		  echo "<td> $cep </td>";
		  echo "<td> $bairro </td>";
		  echo "<td> $logradouro </td>";
		  echo "<td> $complemento </td>";
		  echo "<td> $rua </td>";
		  echo "<td> $numero </td>";
		    
		  // cria link para EXCLUSAO do respectivo id_curso
		  echo '<td><a href="excluiCliente.php?id='. $row["idCliente"] . '">Excluir</a></td>';
		  // cria link para ALTERACAO do respectivo id_curso
		  echo '<td><a href="alteraCliente.php?id='. $row["idCliente"] . '"  >Alterar</a></td>';
		  
		  echo "</tr>";
	  }
	  echo "</table>";
	  // libera a área de memória onde está o resultado
	  mysqli_free_result($result);
  }
  // fecha a conexão
  mysqli_close($link);
?>  
</div>
	
	
	
	<script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
	</body>
</html>
