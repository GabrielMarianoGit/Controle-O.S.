<!DOCTYPE html>
<!-- cadastro.php 
     lista os cursos cadastrados -->
<html>
	<head>
		<title>O.S. Control</title>
		<meta charset="utf-8">
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Os`s Cadastradas</title>
		<link href="../css/bootstrap.min.css" rel="stylesheet">
		<link href="../css/style.css" rel="stylesheet">
	</head>
	<body>

	<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">O.S. control</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.html">In&iacute;cio</a></li>
                    <li>
                        <div class="dropdown">
                            <button class="dropbtn">Cadastrar</button>
                            <div class="dropdown-content">
                                <a href="cadastraFuncionario.php">Cadastrar Funcionário</a>
                                <a href="cadastraOs.php">Cadastrar O.S.</a>
                                <a href="cadastraCliente.php">Cadastrar Cliente</a>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="dropdown">
                            <button class="dropbtn">Gerenciar</button>
                            <div class="dropdown-content">
                                 <a href="gerenciaCliente.php">Gerenciar Cliente</a>
                                <a href="gerenciaFuncionario.php">Gerenciar Funcionário</a>
                            </div>
                        </div>
                    </li>
                    <li><a href="#">Ajuda</a></li>
                </ul>
            </div>
        </div>
    </nav>
	</br>
	</br>
	<h1>Ordens de serviço cadastradas</h1>
	<div id="tabelaCliente">
	<?php //cadastro.php
// lista clientes cadastrados  

  include_once "../Controler/conectabd.inc.php";

  
  
  // lista clientes já cadastrados
  $query = "SELECT idOs, valoOrcamento, dataInicio, dataFim, modeloProduto, marcaProduto, valorPago, dataPagamento, statusOs, FK_Funcionario, FK_Cliente FROM os;";
  if ($result = mysqli_query($link, $query)) {
	  echo "<table border='1'>";
	  echo "<tr>
	          <th>ID</th>
			  <th>Valor Orçamento</th>
			  <th>Data Inicio</th>
			  <th>Data Final</th>
			  <th>Modelo</th>
			  <th>Marca</th>
			  <th>Valor Pago</th>
			  <th>Data Pagamento</th>
			  <th>Status da Os</th>
			  <th>Funcionário</th>
			  <th>Cliente</th>
			  
			</tr>";
	  // busca os dados lidos do banco de dados
	  while ($row = mysqli_fetch_assoc($result)) {
		  $idOs = $row["idOs"];
		  $valoOrcamento = $row["valoOrcamento"];
		  $dataInicio= $row["dataInicio"];
		  $dataFim = $row["dataFim"];
		  $modeloProduto = $row["modeloProduto"];
		  $marcaProduto = $row["marcaProduto"];
		  $valorPago = $row["valorPago"];
		  $dataPagamento = $row["dataPagamento"];
		  $statusOs = $row["statusOs"];
		  $FK_Funcionario = $row["FK_Funcionario"];
		  $FK_Cliente = $row["FK_Cliente"];
		  echo "<tr>";
		  echo "<td> $idOs </td>";
		  echo "<td> $valoOrcamento </td>";
		  echo "<td> $dataInicio </td>";
		  echo "<td> $dataFim </td>";
		  echo "<td> $modeloProduto </td>";
		  echo "<td> $marcaProduto </td>";
		  echo "<td> $valorPago </td>";
		  echo "<td> $dataPagamento </td>";
		  echo "<td> $statusOs </td>";
		  echo "<td> $FK_Funcionario </td>";
		  echo "<td> $FK_Cliente </td>";
		    
		 
		  echo "</tr>";
	  }
	  echo "</table>";
	  // libera a área de memória onde está o resultado
	  mysqli_free_result($result);
  }
  // fecha a conexão
  mysqli_close($link);
?>  
</div>
	
	
	
	<script src="../js/jquery.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
	</body>
</html>
