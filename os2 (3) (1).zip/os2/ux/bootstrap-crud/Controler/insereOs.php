 <?php 
 include_once "../Controler/conectabd.inc.php";
 
 $valoOrcamento = $_GET["lblOrcamento"];
 $dataInicio = $_GET["lblDataInicio"];
 $dataFim = $_GET["lblDataFim"];
 $modeloProduto = $_GET["lblModelo"];
 $marcaProduto = $_GET["lblMarca"];
 
 $valorPago = $_GET["lblValorPago"];
 $dataPagamento = $_GET["lblDataPagamento"];
 $statusOs = $_GET["lblStatus"];
 $FK_Funcionario = $_GET["lblCpfFunc"];
 $FK_Cliente = $_GET["lblCpfCliente"];
 
 
$query = "insert into os 
      (valoOrcamento, dataInicio, dataFim, modeloProduto, marcaProduto, valorPago, dataPagamento, statusOs, FK_Funcionario, FK_Cliente) 
	  values ('$valoOrcamento', '$dataInicio', '$dataFim', '$modeloProduto' ,'$marcaProduto' ,'$valorPago' ,'$dataPagamento' ,'$statusOs' ,'$FK_Funcionario' ,'$FK_Cliente');";
  if ($result = mysqli_query($link, $query)) {
	  echo "
	  <h1>Inclusão efetuada com sucesso</h1>
	  ";
	  header("refresh: 2;http://localhost/os2/ux/bootstrap-crud/View/cadastraOs.php");
  }
  
  mysqli_close($link);
  
  
 ?>