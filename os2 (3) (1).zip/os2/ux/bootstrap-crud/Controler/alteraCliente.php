<!DOCTYPE html>
<html>

<head>
    <title>-Alteração-</title>
    <meta charset="utf-8">
</head>

<body>
    <?php 
 
   $nome = $_GET["lblNome"];
 $cpf = $_GET["lblCpf"];
 $sexo = $_GET["lblSexo"];
 $telefone = $_GET["lblTelefone"];
 $estado = $_GET["slcEstado"];
 $cidade = $_GET["lblCidade"];
 $bairro = $_GET["lblBairro"];
 $logradouro = $_GET["lblLougradouro"];
 $complemento = $_GET["lblComplemento"];
 $cep = $_GET["lblCep"];
 $rua = $_GET["lblRua"];
 $numero = $_GET["lblNumero"];
  $id = $_GET["lblId"];
  include_once "../Controler/conectabd.inc.php";
  $query = "UPDATE cliente 
      SET nomeCliente = '$nome', cpfCliente = '$cpf', sexo = '$sexo', telefone = '$telefone', estado = '$estado', cep = '$cep', bairro = '$bairro', logradouro = '$logradouro', complemento = '$complemento', rua = '$rua', numero = '$numero'
	  WHERE idCliente = $id;";
  if ($result = mysqli_query($link, $query)) {
	  echo "<h1>Alteração efetuada com sucesso</h1>";
  } else {
	  echo mysqli_error($link);
  }
  mysqli_close($link);
?>
   
   <meta http-equiv="refresh" content="2; URL='../View/gerenciaClientes.php'"/>
   
</body>

</html>
