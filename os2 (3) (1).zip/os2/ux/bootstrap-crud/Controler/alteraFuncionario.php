<!DOCTYPE html>
<html>

<head>
    <title>-Alteração-</title>
    <meta charset="utf-8">
</head>

<body>
    <?php 
 
   $nome = $_GET["lblNomeF"];
 $cpf = $_GET["lblCpfF"];
 $telefone = $_GET["lblTelefoneF"];
 $email = $_GET["lblEmailF"];
 $sexo = $_GET["lblSexoF"];
 $codigo = $_GET["lblCodigoF"];
 $estadoCivil = $_GET["lblEstadoCivilF"];
 $cargo = $_GET["lblCargoF"];
 $dataNascimento = $_GET["lblDataNascF"];
 $dataRegistro = $_GET["lblDataRgstF"];
  $id = $_GET["lblId"];
  include_once "../Controler/conectabd.inc.php";
  $query = "UPDATE funcionario 
      SET nome = '$nome', cpf = '$cpf', telefone = '$telefone', email = '$email', sexo = '$sexo', estadoCivil = '$estadoCivil', cargo = '$cargo', dataNascimento = '$dataNascimento', dataRegistro = '$dataRegistro'
	  WHERE idFuncionario = $id;";
  if ($result = mysqli_query($link, $query)) {
	  echo "<h1>Alteração efetuada com sucesso</h1>";
  } else {
	  echo mysqli_error($link);
  }
  mysqli_close($link);
?>
   
   <meta http-equiv="refresh" content="2; URL='../View/gerenciaFuncionario.php'"/>
   
</body>

</html>
