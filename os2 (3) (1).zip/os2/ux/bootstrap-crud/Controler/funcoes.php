<?php  

function le_consulta($con, $id){  
  $row = array();
  $query = "SELECT idCliente, nomeCliente, cpfCliente, sexo, telefone, estado, cep, bairro, logradouro, complemento, rua, numero FROM cliente where idCliente = $id;";
  if ($result = mysqli_query($con, $query)) {
	  if ($row = mysqli_fetch_assoc($result)) {
		  // libera a área de memória onde está o resultado
		  mysqli_free_result($result);
		  
		  return $row;
 	  }

  }
}


function le_consultaF($con, $id){  
  $row = array();
  $query = "SELECT idFuncionario, nome, cpf, telefone, email, sexo, estadoCivil, cargo, dataNascimento, dataRegistro FROM funcionario where idFuncionario = $id;";
  if ($result = mysqli_query($con, $query)) {
	  if ($row = mysqli_fetch_assoc($result)) {
		  // libera a área de memória onde está o resultado
		  mysqli_free_result($result);
		  
		  return $row;
 	  }

  }
}
