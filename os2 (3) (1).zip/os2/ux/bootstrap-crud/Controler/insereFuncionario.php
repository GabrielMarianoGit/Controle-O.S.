 <?php 
 include_once "../Controler/conectabd.inc.php";
 
 $nome = $_GET["lblNomeF"];
 $cpf = $_GET["lblCpfF"];
 $telefone = $_GET["lblTelefoneF"];
 $email = $_GET["lblEmailF"];
 $sexo = $_GET["lblSexoF"];
 $codigo = $_GET["lblCodigoF"];
 $estadoCivil = $_GET["lblEstadoCivilF"];
 $cargo = $_GET["lblCargoF"];
 $dataNascimento = $_GET["lblDataNascF"];
 $dataRegistro = $_GET["lblDataRgstF"];
 
 
$query = "insert into funcionario 
      (nome, cpf, telefone, email, sexo, estadoCivil, cargo, dataNascimento, dataRegistro) 
	  values ('$nome', '$cpf', '$telefone', '$email' ,'$sexo' ,'$estadoCivil' ,'$cargo' ,'$dataNascimento' ,'$dataRegistro');";
  if ($result = mysqli_query($link, $query)) {
	  echo "
	  <h1>Inclusão efetuada com sucesso</h1>
	  ";
	  header("refresh: 2;http://localhost/os2/ux/bootstrap-crud/View/cadastraFuncionario.php");
  }
  mysqli_close($link);
  
  
 ?>