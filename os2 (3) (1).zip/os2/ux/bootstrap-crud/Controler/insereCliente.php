 <?php 
 include_once "../Controler/conectabd.inc.php";
 
 $nome = $_GET["lblNome"];
 $cpf = $_GET["lblCpf"];
 $sexo = $_GET["lblSexo"];
 $telefone = $_GET["lblTelefone"];
 $estado = $_GET["slcEstado"];
 $cidade = $_GET["lblCidade"];
 $bairro = $_GET["lblBairro"];
 $lougradouro = $_GET["lblLougradouro"];
 $complemento = $_GET["lblComplemento"];
 $cep = $_GET["lblCep"];
 $rua = $_GET["lblRua"];
 $numero = $_GET["lblNumero"];
 
$query = "insert into cliente 
      (nomeCliente, cpfCliente, sexo, telefone, estado, cep, bairro, logradouro, complemento, rua, numero) 
	  values ('$nome', '$cpf', '$sexo', '$telefone' ,'$estado' ,'$cep' ,'$bairro' ,'$lougradouro' ,'$complemento' ,'$rua' ,'$numero');";
  if ($result = mysqli_query($link, $query)) {
	  echo "
	  <h1>Inclusão efetuada com sucesso</h1>
	  ";
	  header("refresh: 2;http://localhost/os2/ux/bootstrap-crud/View/cadastraCliente.php");
  }
  mysqli_close($link);
  
  
 ?>